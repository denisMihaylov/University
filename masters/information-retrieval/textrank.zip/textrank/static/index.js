function submit() {
	const textField = document.getElementById('text');
	console.log(textField.value);
}
